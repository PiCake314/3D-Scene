# 3D-Scene (A simple classroom) - Ali Almutawa Jr.


## How to Run:
1. run "make clean"
1. run "make"
1. run "make run" (or ./hw2)


## Modes:
Press 'm' to toggle between different modes:
    - 0: 1st Person Mode
    - 1: Orhogonal Mverhead View
    - 2: Perspective Overhead View

## Controls for 1st Person Mode:
1. (w, a, s, d) for moving the player (yourself) forward, left, backwards, right.
1. Press the spacebar to move up, and (`) to move down.
1. Left, right, up, and down arrows control the player's rotation.



---
- Time spent: 12 hours ;-;.
